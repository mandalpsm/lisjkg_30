Academic Research Explorer - knowledge graph update package

original/        Uploaded files before changes
  Academic_Research_Explorer_Redesigned.html   original app
  Connected_Relationships_for_different_Nodes.xlsx   relationship schema (source of the 29 relationships)

product/         Updated app (open this in a browser)
  Academic_Research_Explorer_Redesigned.html

source_changes/  Source used to produce the product
  patch.py          applies the exact, count-checked replacements to the original HTML
  new_local.js      schema table, models, and the shared graph builder (local records)
  new_online.js     graph builder for online web results

tests/           Checks run against the product (Node.js)
  app.js            the page's script, extracted from the product HTML
  harness.js        loads the script in Node with a DOM stub and the embedded dataset
  test1.js          dataset load and model scope row counts
  test2.js          builds every model and validates edges against the schema
  test3.js          strict edge check, unchecked types, single record, online and UI paths

To rebuild the product: python3 source_changes/patch.py (paths inside point to /mnt/user-data).
To run tests: cd tests && node test1.js && node test2.js && node test3.js (harness expects the product path given in harness.js).
