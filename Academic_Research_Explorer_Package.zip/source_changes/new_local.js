/* ── Connected-relationship schema (from Connected_Relationships_for_different_Nodes.xlsx) ── */
const KG_ENTITY_TYPE={Author:'author',Title:'paper',Journal:'journal',Publisher:'publisher',Place:'place',Keywords:'keyword',Year:'year',DOI:'doi',URL:'url'};
const KG_REL_SCHEMA=[
{a:'Author',rel:'writes',b:'Title',rev:'is_written_by'},
{a:'Author',rel:'contributes_to',b:'Journal',rev:'has_contributor'},
{a:'Author',rel:'publishes_with',b:'Publisher',rev:'publishes_work_of'},
{a:'Author',rel:'publishes_in_place',b:'Place',rev:'hosts_publications_of'},
{a:'Author',rel:'uses',b:'Keywords',rev:'associated_with'},
{a:'Author',rel:'publishes_in_year',b:'Year',rev:'has_publication_by'},
{a:'Author',rel:'linked_by',b:'DOI',rev:'linked_work_of'},
{a:'Author',rel:'accessible_via',b:'URL',rev:'links_to_work_of'},
{a:'Title',rel:'published_in',b:'Journal',rev:'contains'},
{a:'Title',rel:'published_by',b:'Publisher',rev:'publishes'},
{a:'Title',rel:'published_at',b:'Place',rev:'hosts_publication'},
{a:'Title',rel:'described_by',b:'Keywords',rev:'describes'},
{a:'Title',rel:'appears_in',b:'Year',rev:'includes_title'},
{a:'Title',rel:'identified_by',b:'DOI',rev:'represents'},
{a:'Title',rel:'available_at',b:'URL',rev:'links_to'},
{a:'Journal',rel:'issued_by',b:'Publisher',rev:'issues'},
{a:'Journal',rel:'published_at',b:'Place',rev:'hosts_journal'},
{a:'Journal',rel:'indexed_by',b:'Keywords',rev:'used_in'},
{a:'Journal',rel:'active_in',b:'Year',rev:'includes_journal'},
{a:'Journal',rel:'represented_by',b:'DOI',rev:'represents_journal'},
{a:'Journal',rel:'accessible_at',b:'URL',rev:'links_to_journal'},
{a:'Publisher',rel:'located_in',b:'Place',rev:'hosts_publisher'},
{a:'Publisher',rel:'connected_with',b:'Keywords',rev:'connected_by'},
{a:'Publisher',rel:'operates_in',b:'Year',rev:'has_published_by'},
{a:'Publisher',rel:'assigns',b:'DOI',rev:'assigned_by'},
{a:'Publisher',rel:'provides',b:'URL',rev:'from_publisher'},
{a:'Place',rel:'associated_with',b:'Keywords',rev:'linked_to_place'},
{a:'Place',rel:'active_in',b:'Year',rev:'includes_place'},
{a:'Keywords',rel:'relevant_in',b:'Year',rev:'has_keywords'}
];
/* Which schema rows each model draws. Title is the hub and is always present. */
const KG_MODEL_SCOPE={
  bibliographic:{},
  coauthorship:{focus:'Author'},
  concept:{focus:'Keywords'},
  ecosystem:{within:['Publisher','Journal','Place']},
  temporal:{focus:'Year'},
  ner:{within:['Author','Journal','Publisher','Place','Keywords','DOI']}
};
function kgModelRows(modelId){
  const sc=KG_MODEL_SCOPE[modelId]||{};
  return KG_REL_SCHEMA.filter(r=>{
    if(sc.focus) return r.a===sc.focus||r.b===sc.focus;
    if(sc.within) return [r.a,r.b].every(x=>x==='Title'||sc.within.includes(x));
    return true;
  });
}
function kgLegendFor(modelId){
  const lines=kgModelRows(modelId).map(r=>`<b>${esc(r.rel)}</b> — ${esc(r.a)} → ${esc(r.b)} <span style="color:var(--muted)">(reverse: ${esc(r.rev)})</span>`);
  lines.unshift('<b>matched search</b> — Title is in the current result set (query node)');
  return lines.join('<br>');
}

/* ── Multiple Knowledge-Graph construction models (views of the schema above) ── */
const KG_MODELS = {
  bibliographic: {
    id: 'bibliographic',
    label: 'Bibliographic Metadata Model',
    desc: 'Full connected-relationship schema: every relationship in the sheet is drawn between the Title, Author, Journal, Publisher, Place, Keywords, Year, DOI and URL nodes of each record.',
    relations: kgLegendFor('bibliographic')
  },
  coauthorship: {
    id: 'coauthorship',
    label: 'Co-Authorship / Collaboration Network',
    desc: 'Author-centred view: only relationships where Author is one end are drawn (writes, contributes_to, publishes_with, uses, and so on).',
    relations: kgLegendFor('coauthorship')
  },
  concept: {
    id: 'concept',
    label: 'Concept / Keyword Co-occurrence Model',
    desc: 'Keyword-centred view: only relationships that involve Keywords are drawn (described_by, uses, indexed_by, connected_with, associated_with, relevant_in).',
    relations: kgLegendFor('concept')
  },
  ecosystem: {
    id: 'ecosystem',
    label: 'Publishing Ecosystem Model',
    desc: 'Publisher, Journal and Place relationships only (issued_by, published_at, located_in, published_by, published_in, and their Title links).',
    relations: kgLegendFor('ecosystem')
  },
  temporal: {
    id: 'temporal',
    label: 'Temporal Impact Model',
    desc: 'Year-centred view: only relationships that involve Year are drawn (appears_in, publishes_in_year, active_in, operates_in, relevant_in).',
    relations: kgLegendFor('temporal')
  },
  ner: {
    id: 'ner',
    label: 'NER Entity-Relation Model',
    desc: 'Entities extracted from titles, abstracts and metadata are attached to their records with the same schema: persons as Author, organisations as Publisher, locations as Place, methods and concepts as Keywords, identifiers as DOI, journals as Journal.',
    relations: kgLegendFor('ner')
  }
};

/* Generic builder. items: [{key, rank, score, o:{title,year,source,publisher,place,doi,url,cites}, authors:[], keywords:[]}] */
function kgSchemaBuild(items, modelId='bibliographic', opts={}){
  const model = KG_MODELS[modelId] || KG_MODELS.bibliographic;
  const active = new Set(opts.types ? [...opts.types] : ['author','journal','publisher','place','keyword','year','doi','url']);
  const isOn = name => KG_ENTITY_TYPE[name]==='paper' || active.has(KG_ENTITY_TYPE[name]);
  const rows = kgModelRows(model.id).filter(r => isOn(r.a) && isOn(r.b));
  const used = new Set(rows.flatMap(r => [r.a, r.b]));
  const map = new Map(), edges = [], edgeSeen = new Set();
  const addEdge = (a, b, relation, detail='', rev='') => {
    if(!a || !b || a === b) return;
    const ek = [a.id, b.id, relation].sort().join('§');
    if(edgeSeen.has(ek)) return;
    edgeSeen.add(ek);
    edges.push({a, b, relation, detail, rev});
  };
  const qn = opts.includeSearchRoot !== false
    ? kgAddNode(map, {type:'query', label: opts.rootLabel || 'Current result set', weight: Math.max(1, items.length)})
    : null;

  const perPaper = [];
  items.forEach((it, rank) => {
    const o = it.o;
    const pn = kgAddNode(map, {type:'paper', label: o.title || 'Untitled', paperIndex: it.key, cites: o.cites || 0,
      year: o.year, source: o.source, rank: rank + 1, score: it.score || 0, weight: 1 + Math.log1p(o.cites || 0), url: o.url || ''});
    if(qn) addEdge(qn, pn, 'matched search', `rank ${rank + 1}`);
    const ents = {Title: [pn]};
    const add = (name, node) => { if(node) (ents[name] = ents[name] || []).push(node); };
    if(used.has('Author')) it.authors.slice(0, 8).forEach(a => add('Author', kgAddNode(map, {type:'author', label:a})));
    if(used.has('Journal') && o.source) add('Journal', kgAddNode(map, {type:'journal', label:o.source}));
    if(used.has('Publisher') && o.publisher) add('Publisher', kgAddNode(map, {type:'publisher', label:o.publisher}));
    if(used.has('Place') && o.place) add('Place', kgAddNode(map, {type:'place', label:o.place}));
    if(used.has('Keywords')) it.keywords.slice(0, 8).forEach(k => add('Keywords', kgAddNode(map, {type:'keyword', label:k})));
    if(used.has('Year') && o.year) add('Year', kgAddNode(map, {type:'year', label:String(o.year)}));
    const doi = String(o.doi || '').replace(/^https?:\/\/(dx\.)?doi\.org\//i, '').trim();
    if(used.has('DOI') && doi) add('DOI', kgAddNode(map, {type:'doi', label:doi}));
    const pageUrl = safeUrl(o.url);
    if(used.has('URL') && pageUrl) add('URL', kgAddNode(map, {type:'url', label:pageUrl.replace(/^https?:\/\//, ''), url:pageUrl}));
    perPaper.push({key: pn.id, ents});
  });

  // NER-extracted entities are attached to the records they were found in, using the same schema names
  if(modelId === 'ner' && opts.nerHits && typeof riNER === 'function'){
    const ner = riNER(opts.nerHits);
    const catMap = {person:'Author', organization:'Publisher', location:'Place', method:'Keywords', concept:'Keywords', identifier:'DOI', journal:'Journal'};
    Object.keys(catMap).forEach(cat => {
      const name = catMap[cat];
      if(!used.has(name)) return;
      const m = ner[cat];
      if(!m) return;
      const entries = m instanceof Map ? [...m.values()] : [];
      entries.slice(0, 20).forEach(e => {
        const node = kgAddNode(map, {type: KG_ENTITY_TYPE[name], label: e.label, weight: e.count || 1});
        (e.papers || []).forEach(pi => {
          const pp = perPaper.find(p => p.key === 'paper|' + pi);
          if(pp) (pp.ents[name] = pp.ents[name] || []).push(node);
        });
      });
    });
  }

  // Every edge comes from the schema: A --rel--> B, with the reverse name shown from the B end
  perPaper.forEach(pp => {
    rows.forEach(r => {
      const A = pp.ents[r.a] || [];
      const B = pp.ents[r.b] || [];
      A.forEach(x => B.forEach(y => addEdge(x, y, r.rel, `${r.a} → ${r.b}`, r.rev)));
    });
  });

  return {nodes: [...map.values()], edges, model};
}

function kgBuildByModel(hits, modelId='bibliographic', opts={}){
  const limit = Number(opts.limit || 20);
  const chosen = hits.slice(0, limit);
  const items = chosen.map((h, rank) => {
    const idx = h.i ?? h, o = recObj(idx);
    const doiText = String(o.doi || '').replace(/^https?:\/\/(dx\.)?doi\.org\//i, '').trim();
    const url = safeUrl(o.url) || (doiText ? 'https://doi.org/' + doiText : '');
    return {
      key: idx, rank, score: h.score || 0,
      o: {title:o.title, year:o.year, source:o.source, publisher:o.publisher, place:o.place, doi:o.doi, url, cites:o.cites},
      authors: splitAuthors(o.authors),
      keywords: splitKeywords(o.keywords)
    };
  });
  const q = (state.query || '').trim();
  return kgSchemaBuild(items, modelId, {
    types: opts.types,
    includeSearchRoot: opts.includeSearchRoot !== false,
    rootLabel: q ? `Query: ${q}` : 'Current result set',
    nerHits: chosen.map(h => ({i: h.i ?? h}))
  });
}
