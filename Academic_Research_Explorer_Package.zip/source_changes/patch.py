import sys
SRC='/mnt/user-data/uploads/Academic_Research_Explorer_Redesigned.html'
DST='/mnt/user-data/outputs/Academic_Research_Explorer_Redesigned.html'
t=open(SRC,encoding='utf-8').read()

def rep1(old,new):
    global t
    n=t.count(old)
    assert n==1, f'expected 1 match, got {n}: {old[:80]!r}'
    t=t.replace(old,new)

def repall(old,new,expected):
    global t
    n=t.count(old)
    assert n==expected, f'expected {expected} matches, got {n}: {old[:80]!r}'
    t=t.replace(old,new)

# 1. colours and names for the new node types
rep1("identifier:'#475569',method:'#db2777',",
     "identifier:'#475569',place:'#be185d',doi:'#64748b',url:'#0369a1',method:'#db2777',")
rep1("paper:'Paper',", "paper:'Title',")
rep1("country:'Country',year:'Year',", "country:'Country',place:'Place',doi:'DOI',url:'URL',year:'Year',")

# 2. URL resolution for the new node types
rep1(r"function nodeUrlFor(type,label,o){const enc=s=>encodeURIComponent(String(s||'').trim());",
     r"""function nodeUrlFor(type,label,o){const enc=s=>encodeURIComponent(String(s||'').trim());if(type==='doi'){let d=String(label||'').trim().replace(/^https?:\/\/(dx\.)?doi\.org\//i,'');return d?'https://doi.org/'+d:''}if(type==='url')return safeUrl(label);if(type==='place')return 'https://www.google.com/maps/search/?api=1&query='+enc(label);""")

# 3. recObj must understand online result keys ('online|N') used by the online graph
rep1("function recObj(i){const r=R[i];",
     "function recObj(i){if(typeof i==='string'&&i.indexOf('online|')===0)return onlineRecObj(i);const r=R[i];")

# 4. Replace the model table and the local graph builder
start_marker="/* ── Multiple appropriate Knowledge-Graph construction models ── */"
end_marker="  return {nodes:[...map.values()], edges, model};\n}\n"
assert t.count(start_marker)==1
s=t.index(start_marker)
e=t.index(end_marker,s)+len(end_marker)
t=t[:s]+open('/home/claude/new_local.js',encoding='utf-8').read()+t[e:]

# 5. Replace the online graph builder
start_marker2="function kgBuildFromOnline(results, modelId='bibliographic', opts={}){"
end_marker2="  return { nodes: [...map.values()], edges, model };\n}\n"
assert t.count(start_marker2)==1
s=t.index(start_marker2)
e=t.index(end_marker2,s)+len(end_marker2)
t=t[:s]+open('/home/claude/new_online.js',encoding='utf-8').read()+t[e:]

# 6. Type checkboxes: Countries -> Places, plus DOIs and URLs
rep1('value="country" checked>Countries</label>', 'value="place" checked>Places</label>')
rep1('value="year" checked>Years</label>',
     'value="year" checked>Years</label><label><input type="checkbox" class="kgType" value="doi" checked>DOIs</label><label><input type="checkbox" class="kgType" value="url" checked>URLs</label>')

# 7. Type filter: checkboxes are now the only source of enabled node types
a="  // When a specialised model is chosen, prefer its canonical types unless user overrides"
b="  const limit = isSingle ? hits.length"
assert t.count(a)==1 and t.count(b)==1
s=t.index(a); e=t.index(b)
t=t[:s]+t[e:]

# 8. Node types that support 'search by node'
repall("['journal','publisher','country','year','keyword','author']",
       "['journal','publisher','place','year','keyword','author']", 2)
rep1("else if(n.type==='country'){let idx=CO.findIndex(x=>norm(x)===norm(n.label));if(idx>=0){state.country=String(idx);$('#countryFilter').value=state.country}}",
     "else if(n.type==='place'){state.query='\"'+n.label+'\"';$('#q').value=state.query}")

# 9. Relationship list shows the reverse name when viewed from the B end
rep1('<div class="kg-rel"><b>${esc(e.relation)}</b>',
     '<div class="kg-rel"><b>${esc(e.rev&&e.b===n?e.rev:e.relation)}</b>')

open(DST,'w',encoding='utf-8').write(t)
print('written', len(t))
