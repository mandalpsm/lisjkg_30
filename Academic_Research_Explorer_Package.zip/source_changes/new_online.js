function kgBuildFromOnline(results, modelId='bibliographic', opts={}){
  const limit = Number(opts.limit || 20);
  const chosen = (results || []).slice(0, limit);
  const items = chosen.map((r, rank) => {
    const url = safeUrl(r.url) || (r.doi ? 'https://doi.org/' + r.doi : '');
    return {
      key: 'online|' + rank, rank, score: 1,
      o: {title: r.title || 'Untitled', year: r.year || '', source: r.source || '', publisher: '', place: '', doi: r.doi || '', url, cites: r.cites || 0},
      authors: String(r.authors || '').split(/;| and |,/).map(x => x.trim()).filter(Boolean),
      keywords: String(r.keywords || '').split(/;|,/).map(x => x.trim()).filter(x => x.length > 2)
    };
  });
  const q = (opts.query || state.query || '').trim();
  return kgSchemaBuild(items, modelId, {
    types: opts.types,
    includeSearchRoot: opts.includeSearchRoot !== false,
    rootLabel: q ? `Online query: ${q}` : 'Online web results'
  });
}
