const {ctx, vm} = require('./harness.js');
const run = code => vm.runInContext(code, ctx);
const tick = () => new Promise(r => setImmediate(r));
(async () => {
  for (let i = 0; i < 5; i++) await tick();
  // use the first 20 records of the dataset as the "search results"
  run('state.query = ""; globalThis.__hits = Array.from({length:20},(_,i)=>({i: 100+i*37}));');
  const schemaOK = run(`(() => { const ok = new Set(KG_REL_SCHEMA.map(r => r.rel)); ok.add('matched search'); return ok; })()`);
  for (const m of ['bibliographic','coauthorship','concept','ecosystem','temporal','ner']) {
    const out = run(`(() => {
      const g = kgBuildByModel(__hits, "${m}", {limit: 20, types: new Set(['author','journal','keyword','publisher','place','year','doi','url'])});
      const rels = {}; const typeErrors = [];
      const byType = {};
      g.nodes.forEach(n => byType[n.type] = (byType[n.type]||0)+1);
      const deg = new Map(); g.nodes.forEach(n => deg.set(n.id, 0));
      g.edges.forEach(e => { deg.set(e.a.id, deg.get(e.a.id)+1); deg.set(e.b.id, deg.get(e.b.id)+1); });
      const isolated = g.nodes.filter(n => deg.get(n.id) === 0 && n.type !== 'query').length;
      g.edges.forEach(e => {
        rels[e.relation] = (rels[e.relation]||0)+1;
        if (e.relation === 'matched search') return;
        const row = KG_REL_SCHEMA.find(r => r.rel === e.relation);
        if (!row) { typeErrors.push('unknown relation ' + e.relation); return; }
        const want = [KG_ENTITY_TYPE[row.a], KG_ENTITY_TYPE[row.b]];
        const got  = [e.a.type, e.b.type];
        if (want[0] !== got[0] || want[1] !== got[1]) typeErrors.push(e.relation + ' expected ' + want + ' got ' + got);
      });
      return JSON.stringify({nodes: g.nodes.length, edges: g.edges.length, isolated, byType, typeErrors: typeErrors.slice(0,5), nErr: typeErrors.length, relCount: Object.keys(rels).length, sampleRels: Object.entries(rels).slice(0,8)});
    })()`);
    console.log(m, out);
  }
  // legend text and the reverse-name display from the B end
  console.log('\nlegend (ecosystem):', run('kgLegendFor("ecosystem")').replace(/<[^>]+>/g,'').slice(0,400));
  const sel = run(`(() => {
    const g = kgBuildByModel(__hits, "bibliographic", {limit: 3, types: new Set(['author','journal','keyword','publisher','place','year','doi','url'])});
    KG.nodes = g.nodes; KG.edges = g.edges;
    const author = g.nodes.find(n => n.type === 'author');
    const title = g.nodes.find(n => n.type === 'paper');
    return {authorRels: kgSelectionHtml(author).match(/kg-rel"><b>[a-z_]+/g).slice(0,4),
            titleRels: kgSelectionHtml(title).match(/kg-rel"><b>[a-z_]+/g).slice(0,4)};
  })()`);
  console.log('\nselection relation labels:', JSON.stringify(sel));
})();
