const fs = require('fs'), vm = require('vm');
const HTML = '/mnt/user-data/outputs/Academic_Research_Explorer_Redesigned.html';
const html = fs.readFileSync(HTML, 'utf8').split('\n');
const dataLine = html[345];
const pre = '<script id="embeddedData" type="application/json">';
const dataJson = dataLine.slice(pre.length, dataLine.lastIndexOf('</script>'));
const app = fs.readFileSync('/home/claude/app.js', 'utf8');

function makeStub(){
  const base = function(){};
  const handler = {
    get(t, k){
      if (k === Symbol.iterator) return function*(){};
      if (k === Symbol.toPrimitive) return () => '';
      if (k === 'then') return undefined;
      if (k === 'value') return '';
      if (k === 'checked') return false;
      if (k === 'textContent' || k === 'innerHTML') return '';
      if (k === 'getContext') return () => proxy;
      if (k === 'getBoundingClientRect') return () => ({width:800,height:600,left:0,top:0});
      return proxy;
    },
    set(){ return true; },
    apply(){ return proxy; },
    construct(){ return proxy; }
  };
  const proxy = new Proxy(base, handler);
  return proxy;
}
const docStub = makeStub();
const ctx = {
  console, JSON, Math, Date, Map, Set, Array, Object, String, Number, Boolean, RegExp, Error, Promise,
  URL, encodeURIComponent, decodeURIComponent, setTimeout: () => 0, clearTimeout: () => {},
  requestAnimationFrame: () => 0, cancelAnimationFrame: () => {},
  localStorage: makeStub(), sessionStorage: makeStub(),
  devicePixelRatio: 1, innerWidth: 1200, innerHeight: 800,
};
ctx.document = {
  getElementById(id){ if(id==='embeddedData'){ return {textContent: dataJson}; } return makeStub(); },
  querySelector(){ return makeStub(); },
  querySelectorAll(){ return []; },
  createElement(){ return makeStub(); },
  body: makeStub(), documentElement: makeStub(), addEventListener(){}
};
ctx.window = ctx; ctx.addEventListener = () => {};
vm.createContext(ctx);
try {
  vm.runInContext(app, ctx, {filename: 'app.js'});
} catch (e) {
  console.log('LOAD ERROR:', e.message); process.exit(1);
}
module.exports = {ctx, vm};
