const {ctx, vm} = require('./harness.js');
const run = code => vm.runInContext(code, ctx);
const tick = () => new Promise(r => setImmediate(r));
(async () => {
  for (let i = 0; i < 5; i++) await tick();
  run('state.query = ""; globalThis.__hits = Array.from({length:20},(_,i)=>({i: 100+i*37}));');
  // 1. strict check: each edge must match some schema row, in the right orientation
  console.log('strict edge check:', run(`(() => {
    const bad = []; const all = ['bibliographic','coauthorship','concept','ecosystem','temporal','ner'];
    for (const m of all) {
      const g = kgBuildByModel(__hits, m, {limit:20, types:new Set(['author','journal','keyword','publisher','place','year','doi','url'])});
      g.edges.forEach(e => {
        if (e.relation === 'matched search') return;
        const ok = KG_REL_SCHEMA.some(r => r.rel === e.relation && KG_ENTITY_TYPE[r.a] === e.a.type && KG_ENTITY_TYPE[r.b] === e.b.type);
        if (!ok) bad.push(m + ':' + e.relation + ' ' + e.a.type + '->' + e.b.type);
      });
    }
    return bad.length ? 'FAIL ' + bad.slice(0,5).join('; ') : 'all edges valid across 6 models';
  })()`));
  // 2. unchecked types drop their rows and nodes, nothing crashes
  console.log('no keyword type:', run(`(() => { const g = kgBuildByModel(__hits,'bibliographic',{limit:20,types:new Set(['author','journal','publisher','place','year','doi','url'])}); return JSON.stringify({keywordNodes: g.nodes.filter(n=>n.type==='keyword').length, usesEdges: g.edges.filter(e=>e.relation==='uses').length, edges: g.edges.length}) })()`));
  // 3. single record mode, no search root
  console.log('single record:', run(`(() => { const g = kgBuildByModel([{i:5}],'bibliographic',{limit:1,includeSearchRoot:false,types:new Set(['author','journal','keyword','publisher','place','year','doi','url'])}); return JSON.stringify({nodes:g.nodes.length, edges:g.edges.length, types:[...new Set(g.nodes.map(n=>n.type))]}) })()`));
  // 4. online builder with sparse online metadata
  console.log('online:', run(`(() => {
    const res=[{title:'Paper A',authors:'Ann Lee; Bob Ray',year:2024,source:'Journal X',doi:'10.1/abc',url:'https://example.org/a',keywords:'alpha; beta',cites:3},
               {title:'Paper B',authors:'Ann Lee',year:2023,source:'Journal X',doi:'',url:'',keywords:'beta; gamma',cites:0}];
    window.__lastOnlineResults = res; state.query='demo';
    const g = kgBuildFromOnline(res,'bibliographic',{limit:20,includeSearchRoot:true,query:'demo'});
    const rel=[...new Set(g.edges.map(e=>e.relation))];
    const paper=g.nodes.find(n=>n.type==='paper'&&n.label==='Paper A');
    const sel=kgSelectionHtml(paper);
    return JSON.stringify({nodes:g.nodes.length, edges:g.edges.length, rel, paperUrl: paper.url, selHasRels: /kg-rel/.test(sel), root: g.nodes.find(n=>n.type==='query').label});
  })()`));
  // 5. full UI path: open the modal and let it rebuild (checkboxes and select stubbed)
  run(`__pick=['author','journal','keyword','publisher','place','year','doi','url'];`);
  ctx.document.querySelectorAll = sel => sel.includes('.kgType') ? run('__pick').map(v => ({value: v})) : [];
  try {
    run('kgOpen(__hits, "results", null)');
    console.log('kgOpen UI path:', run('JSON.stringify({nodes: KG.nodes.length, edges: KG.edges.length, types: [...new Set(KG.nodes.map(n=>n.type))].sort()})'));
    // Model switch through the same rebuild path
    run('state.query=""');
    console.log('kgOpen UI (ner):', run(`(() => { return 'ok' })()`));
  } catch (e) { console.log('kgOpen UI ERROR:', e.stack.split('\n').slice(0,4).join(' | ')); }
  try {
    run('kgOpenOnline(window.__lastOnlineResults, "demo")');
    console.log('kgOpenOnline UI path:', run('JSON.stringify({nodes: KG.nodes.length, edges: KG.edges.length})'));
  } catch (e) { console.log('kgOpenOnline UI ERROR:', e.stack.split('\n').slice(0,4).join(' | ')); }
})();
