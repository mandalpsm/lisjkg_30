const {ctx, vm} = require('./harness.js');
const run = code => vm.runInContext(code, ctx);
const tick = () => new Promise(r => setImmediate(r));
(async () => {
  for (let i = 0; i < 5; i++) await tick();
  console.log('records:', run('R ? R.length : "null"'), '| places sample:', run('PLC ? PLC.slice(0,2) : "null"'));
  console.log('models:', run('Object.keys(KG_MODELS).join(",")'));
  console.log('schema rows:', run('KG_REL_SCHEMA.length'));
  for (const m of ['bibliographic','coauthorship','concept','ecosystem','temporal','ner'])
    console.log(m, 'rows =', run(`kgModelRows("${m}").length`));
})();
